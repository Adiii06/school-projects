import streamlit as st
import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow.keras.models import load_model
from sklearn.preprocessing import StandardScaler

# Load the trained model
model_path = r"C:\Users\adief\Desktop\DS168\cnn_pcos.h5"
model = load_model(model_path)

# Load the dataset
dataset_path = r"C:\Users\adief\Desktop\DS168\df1_output.csv"
df = pd.read_csv(dataset_path)

# Keep only the required columns
selected_columns = ['Weight gain(Y/N)', 'hair growth(Y/N)', 'Skin darkening (Y/N)', 'Hair loss(Y/N)', 
                    'Pimples(Y/N)', 'Fast food (Y/N)', 'Age (yrs)', 'Weight (Kg)', 'BMI', 
                    'Pulse rate(bpm)', 'Hb(g/dl)', 'Cycle length(days)', 'Hip(inch)', 'Waist(inch)', 
                    'Follicle No. (L)', 'Follicle No. (R)', 'Avg. F size (L) (mm)', 'Avg. F size (R) (mm)', 
                    'Endometrium (mm)']
df = df[selected_columns]

# Preprocessing function
def preprocess_data(data):
    scaler = StandardScaler()
    scaled_data = scaler.fit_transform(data)
    return np.array(scaled_data).reshape((scaled_data.shape[0], scaled_data.shape[1], 1))

# Streamlit UI
st.title("PCOS Prediction using CNN")

# Display images on the left side
col1, col2 = st.columns([1, 2])
with col1:
    st.image("normal.png", caption="Normal Case", use_column_width=True)
    st.image("pcos.png", caption="PCOS Case", use_column_width=True)

with col2:
    # User choice: Upload CSV or Manual Input
    choice = st.radio("Choose input method:", ("Upload CSV", "Manual Input"))

    if choice == "Upload CSV":
        uploaded_file = st.file_uploader("Choose a CSV file", type=["csv"])
        
        if uploaded_file is not None:
            user_data = pd.read_csv(uploaded_file)
            
            # Ensure only selected columns are used
            user_data = user_data[selected_columns]
            
            st.write("### Uploaded Data Preview")
            st.dataframe(user_data.head())
            
            # Preprocess input data
            processed_data = preprocess_data(user_data)
            
            # Make predictions
            predictions = (model.predict(processed_data) > 0.5).astype(int)
            user_data['PCOS (Y/N)'] = predictions
            
            st.write("### Predictions")
            st.dataframe(user_data[['PCOS (Y/N)']])

    elif choice == "Manual Input":
        st.write("### Manual Input for PCOS Prediction")
        manual_input = {}
        columns = df.columns.tolist()
        all_zero = True  # Flag to check if all inputs are zero
        
        for col in columns:
            value = st.number_input(f"Enter {col}", value=0.0)
            manual_input[col] = value
            if value != 0.0:
                all_zero = False
        
        # Disable button if all values are zero
        disabled = all_zero
        
        if st.button("Predict Manually", disabled=disabled):
            input_df = pd.DataFrame([manual_input])
            processed_input = preprocess_data(input_df)
            prediction = (model.predict(processed_input) > 0.5).astype(int)[0][0]
            st.write(f"### Predicted PCOS: {'Yes' if prediction == 1 else 'No'}")
