import streamlit as st
import pandas as pd
import numpy as np
import tensorflow as tf
from PIL import Image

# Load trained PCA-based model
MODEL_PATH = "C:/Users/adief/Downloads/IOT FINAL/iot.h5"
model = tf.keras.models.load_model(MODEL_PATH)

# Load PCA test file to determine required features
pca_test = pd.read_csv("C:/Users/adief/Downloads/IOT FINAL/pca_test.csv")
input_features = list(pca_test.columns)  # Ensure input features match PCA

# Remove unnecessary column if it exists
if "Activity" in input_features:
    input_features.remove("Activity")

# Activity labels mapping
activity_labels = {
    0: "Laying",
    1: "Sitting",
    2: "Standing",
    3: "Walking",
    4: "Walking Downstairs",
    5: "Walking Upstairs"
}

# Set page layout and background color
st.set_page_config(layout="wide")
st.markdown(
    """
    <style>
        body {
            background-color: #5f5f5f;
            color: white;
        }
    </style>
    """,
    unsafe_allow_html=True
)

# Load and display an image on the side
image_path = "activity.jpg"  # Ensure this path is correct
col1, col2 = st.columns([1, 2])
with col1:
    image = Image.open(image_path)
    st.image(image, use_column_width=True)

with col2:
    # Streamlit UI
    st.title("PCA-Based IoT Activity Prediction")
    
    # Subheading for activity labels
    st.subheader("Activity Labels:")
    for key, value in activity_labels.items():
        st.write(f"{key} = {value}")
    
    # User selects input method
    option = st.radio("Select Input Method:", ["Upload CSV", "Manual Input"], horizontal=True)
    
    if option == "Upload CSV":
        st.write("### Upload a CSV file with PCA-transformed input data")
        uploaded_file = st.file_uploader("Choose a CSV file", type=["csv"])
        
        if uploaded_file is not None:
            input_data = pd.read_csv(uploaded_file)
            input_data = input_data[input_features]  # Ensure correct features
            
            st.write("### Uploaded Data Preview:")
            st.write(input_data.head())
            
            if st.button("Predict"):
                predictions = model.predict(input_data)
                predicted_classes = np.argmax(predictions, axis=1)  # Get predicted class index
                
                st.write("### Prediction Results:")
                st.write(pd.DataFrame(predictions))  # Show raw predictions
                
                # Display activity label
                activity_text = activity_labels.get(predicted_classes[0], "Unknown Activity")
                st.subheader(f"You're {activity_text}!")
    
    else:
        st.write("### Enter PCA-Transformed Values Manually")
        col_left, col_right = st.columns(2)
        input_data = {}
        
        with col_left:
            for feature in input_features[:32]:
                input_data[feature] = st.number_input(f"Enter {feature}", value=0.0)
        
        with col_right:
            for feature in input_features[32:]:
                input_data[feature] = st.number_input(f"Enter {feature}", value=0.0)
        
        data_values = list(input_data.values())
        is_nonzero = any(value != 0 for value in data_values)
        
        predict_button = st.button("Predict from Manual Input", disabled=not is_nonzero)
        
        if predict_button:
            data = np.array([data_values]).reshape(1, -1)
            prediction = model.predict(data)
            predicted_class = np.argmax(prediction)  # Get predicted class index
            
            st.write("### Prediction Result:")
            st.write(prediction)  # Show raw prediction
            
            # Display activity label
            activity_text = activity_labels.get(predicted_class, "Unknown Activity")
            st.subheader(f"You're {activity_text}!")